﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualFunction
{
    class ZiLei:FuLei
    {
        //public override void Hello()
        //{
        //    Console.WriteLine("子类Hello");
        //}

        public void Z()
        {
            Console.WriteLine("子类普通方法.");
        }
    }
}
