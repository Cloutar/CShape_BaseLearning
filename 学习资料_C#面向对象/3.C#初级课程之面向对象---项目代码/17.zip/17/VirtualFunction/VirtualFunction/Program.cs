﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualFunction
{
    class Program
    {
        static void Main(string[] args)
        {
            //实例化一个普通的对象.
            ZiLei z = new ZiLei();
            //z.Hello();
            z.F();
            z.Z();

            //不能实例化抽象类为对象.
            //FuLei f = new FuLei();
            //f.F();


            Console.ReadKey();
        }
    }
}
