﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _22
{
    class Disk
    {
        private string brand;
        public string Brand
        {
            get { return brand; }
            set { brand = value; }
        }

        public Disk(string brand)
        {
            this.brand = brand;
        }
    }
}
