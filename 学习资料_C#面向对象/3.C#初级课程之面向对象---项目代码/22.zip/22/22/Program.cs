﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _22
{
    class Program
    {
        static void Main(string[] args)
        {
            UDisk u1 = new UDisk("金士顿32GB");
            HardDisk h1 = new HardDisk("三星500GB");

            Computer c1 = new Computer("联想");
            c1.Start();
            c1.USB_1 = u1;
            c1.USB_1.Write("擅码网");
            c1.USB_1.Write("MKCODE");
            c1.USB_1.Read();

            c1.USB_2 = h1;
            c1.USB_2.Write("mkcode.net");
            c1.USB_2.Write("lkk");
            c1.USB_2.Read();

            c1.End();

            Console.WriteLine();

            Computer c2 = new Computer("戴尔");
            c2.Start();
            c2.End();

            Console.ReadKey();
        }
    }
}
