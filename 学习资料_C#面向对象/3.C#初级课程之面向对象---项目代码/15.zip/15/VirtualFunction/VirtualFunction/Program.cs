﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualFunction
{
    class Program
    {
        static void Main(string[] args)
        {
            Tiger t = new Tiger();
            t.Cry();

            Console.WriteLine();

            Cat c = new Cat();
            c.Cry();


            Console.ReadKey();
        }
    }
}
