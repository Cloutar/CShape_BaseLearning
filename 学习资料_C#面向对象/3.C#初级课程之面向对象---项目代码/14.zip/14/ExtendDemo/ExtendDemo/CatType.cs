﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtendDemo
{
    class CatType:Animal
    {
        public void YSNL()
        {
            Console.WriteLine("我可以在晚上看到东西");
        }
    }
}
