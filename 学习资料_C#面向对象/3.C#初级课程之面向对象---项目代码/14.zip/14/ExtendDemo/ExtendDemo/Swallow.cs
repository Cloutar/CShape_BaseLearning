﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtendDemo
{
    class Swallow:BirdType
    {
        public void WangNanFei()
        {
            Console.WriteLine("燕子会往南飞");
        }
    }
}
