﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtendDemo
{
    class Cat:CatType
    {
        public void ZhuaLaoShu()
        {
            Console.WriteLine("我可以抓老鼠");
        }
    }
}
