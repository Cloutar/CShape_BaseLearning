﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtendDemo
{
    class BirdType:Animal
    {
        public void Fly()
        {
            Console.WriteLine("鸟可以飞");
        }
    }
}
