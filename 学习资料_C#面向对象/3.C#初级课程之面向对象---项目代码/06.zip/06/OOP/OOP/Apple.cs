﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public enum Color
    {
        Red,
        Green
    }

    class Apple
    {
        public Color color; //颜色.
        public int weight;  //重量.
        public string shape;//形状.

    }
}
