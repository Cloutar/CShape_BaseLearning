﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19
{
    class Program
    {
        static void Main(string[] args)
        {
            BMWCar b1 = new BMWCar("宝马750");
            b1.Run();
            BMWCar b2 = new BMWCar("宝马740");
            b2.Run();

            Batmobile bat1 = new Batmobile("蝙蝠侠战车1");
            bat1.Run();
            bat1.Fly();

            Console.ReadKey();
        }
    }
}
