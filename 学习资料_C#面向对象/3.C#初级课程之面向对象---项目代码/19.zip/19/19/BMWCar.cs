﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19
{
    class BMWCar:Car
    {
        public BMWCar(string brand)
            : base(brand)
        {

        }


    }
}
