﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _28
{
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person("李开坤", 100, "北京海淀");
            p.Hello();
            Console.WriteLine(p.ToString());

            int a = 10;
            Console.WriteLine(a);
            object b = a;           //装箱操作. 值类型-->引用类型.
            Console.WriteLine(b);
            a = (int)b;             //拆箱操作. 引用类型-->值类型.
            Console.WriteLine(a);

            Console.ReadKey();
        }
    }
}
