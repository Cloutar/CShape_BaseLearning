﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualFunction
{
    class Program
    {
        static void Main(string[] args)
        {
           
            //①子类对象可以直接赋值给父类变量.
            
            //②子类对象可以调用父类中的成员，
            //但是父类对象永远只能调用自己的成员；

            //③如果父类对象中装的是子类对象，
            //可以将这个父类对象强转为子类对象；

            //旧版方式.
            Cat c = new Cat();
            c.Cry();
            c.MKCODE();
            c.Monkey();

            Console.WriteLine("---------------------------");

            //现在方式.
            CatType ct = new Cat();
            ct.Cry();
            ct.MKCODE();

            Cat c2 = (Cat)ct;
            c2.Monkey();

            //is：如果转换成功，返回true，失败返回false；
            //bool mk = ct is Tiger;
            //Console.WriteLine(mk);

            //as：如果转换成功，返回对应的对象，失败返回null;
            if(ct as Cat == null)
            {
                Console.WriteLine("转换失败");
            }else{
                Console.WriteLine("转换成功");
            }


            


            Console.ReadKey();
        }
    }
}
