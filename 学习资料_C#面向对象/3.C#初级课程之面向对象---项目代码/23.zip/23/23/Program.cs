﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23
{
    class Program
    {
        static void Main(string[] args)
        {
            Monkey m = new Monkey();
            m.Name = "李开坤";
            Console.WriteLine(m.Name);

            Console.ReadKey();
        }
    }
}
