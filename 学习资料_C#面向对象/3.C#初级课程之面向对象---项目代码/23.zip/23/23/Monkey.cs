﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23
{
    class Monkey:Person
    {
        public void World()
        {
            Console.WriteLine(base.Name);
            Console.WriteLine(base.name);
        }
    }
}
