﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend
{
    class Program
    {
        static void Main(string[] args)
        {
            AiLuoKe m1 = new AiLuoKe("艾洛克", "我是大英雄艾洛克", 80, 90, 100, "Monkey");
            m1.Hello();
            m1.LieYanMaoGou();

            TaiLa m2 = new TaiLa("泰拉", "我是中英雄泰拉", 20, 30, 40, "擅码网");
            m2.Hello();
            m2.JuLangChongJi();


            LuKaShi m3 = new LuKaShi("卢卡斯", "我是小英雄卢卡斯", 40, 50, 60, "mkCode.net");
            m3.Hello();
            m3.NengLiangLangChao();


            Console.ReadKey();
        }
    }
}
