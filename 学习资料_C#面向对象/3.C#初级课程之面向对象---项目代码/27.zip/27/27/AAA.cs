﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _27
{
    /// <summary>
    /// 密封类.
    /// </summary>
    sealed class AAA
    {
    }
}
