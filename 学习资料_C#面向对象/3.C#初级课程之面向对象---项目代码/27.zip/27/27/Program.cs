﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _27
{
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person();
            p.Hello();

            //声明一个嵌套类的对象.
            Person.Web w = new Person.Web();
            w.webName = "擅码网";
            w.webUrl = "www.mkcode.net";
            w.Show();

            //匿名类.
            var mk = new { Name = "lkk", Age = 100, Address = "山东" };
            //mk.Name = "李开坤";
            Console.WriteLine("姓名:{0}, 年龄:{1}, 地址:{2}", mk.Name, mk.Age, mk.Address);



            Console.ReadKey();
        }
    }
}
