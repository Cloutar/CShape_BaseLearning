﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public enum Gender
    {
        男,
        女
    }

    /// <summary>
    /// Person类,描述人.
    /// </summary>
    class Person
    {
        public string name; 
        private int age;
        public Gender gender;

        public int Age
        {
            get { return age; }     //get:取值.
            set 
            { 
                if(value > 100 || value < 0)
                {
                    age = 18;
                }
                else
                {
                    age = value; 
                }
            }    //set:赋值.
        }
    }
}
