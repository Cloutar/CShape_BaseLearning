﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public enum Gender
    {
        男,
        女
    }

    /// <summary>
    /// Person类,描述人.
    /// </summary>
    class Person
    {
        private string name; 
        private int age;
        private Gender gender;
        private string address;

        public Person()
        {

        }

        public Person(string name, int age, Gender gender, string address)
        {
            this.name = name;
            this.age = age;
            this.gender = gender;
            this.address = address;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public Gender Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public int Age
        {
            get { return age; }     //get:取值.
            set 
            { 
                if(value > 100 || value < 0)
                {
                    age = 18;
                }
                else
                {
                    age = value; 
                }
            }    //set:赋值.
        }

        public void Eat()
        {
            Console.WriteLine(Name + "会吃饭");
        }

        public void Sleep()
        {
            Console.WriteLine(Name + "会睡觉");
        }

        public void Work()
        {
            Console.WriteLine(Name + "会工作");
        }

        public void Hello()
        {
            Console.WriteLine("我的名字叫{0},我今年{1}岁,我的性别是{2},我的地址是{3}", Name, Age, Gender, Address);
        }
    }
}
