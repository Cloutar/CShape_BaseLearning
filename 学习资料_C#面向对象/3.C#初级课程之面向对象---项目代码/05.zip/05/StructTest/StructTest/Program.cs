﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructTest
{
    public enum Gender
    {
        男,
        女
    }

    public struct Person
    {
        public string name;
        public int age;
        public Gender gender;
        public string address;
    }


    class Program
    {
        static void Main(string[] args)
        {
            //使用之前讲解的知识，来保存一个人的基本信息，姓名，年龄，性别，地址。

            string name = "Monkey";
            int age = 27;
            Gender gender = Gender.男;
            string address = "北京海淀上地";

            Console.WriteLine(name + age + gender + address);


            Person monkey = new Person();
            monkey.name = "擅码网";
            monkey.age = 1;
            monkey.gender = Gender.男;
            monkey.address = "山东济宁";

            Console.WriteLine(monkey.name + monkey.age + monkey.gender + monkey.address);

            Person p1 = new Person();
            Person p2 = new Person();

            p1.name = "aaaa";

            p2.name = "bbbb";

            Console.ReadKey();

        }
    }
}
