﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _24
{
    class Program
    {
        static void Main(string[] args)
        {
            Person.address = "北京";

            Person p1 = new Person();
            p1.name = "lkk";
            Console.WriteLine(p1.name + "--" + Person.address + "--" + p1.Name + "--" + Person.Address);

            Person p2 = new Person();
            p2.name = "mkcode";
            Console.WriteLine(p2.name + "--" + Person.address + "--" + p2.Name + "--" + Person.Address);
            
            Console.ReadKey();
        }
    }
}
