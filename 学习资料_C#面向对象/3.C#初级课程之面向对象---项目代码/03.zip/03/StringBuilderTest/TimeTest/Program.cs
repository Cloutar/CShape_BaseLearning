﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace TimeTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            /*
            string names = "";
            for (int i = 0; i <= 90000; i++)
            {
                names += i;
            }

            sw.Stop();
            Console.WriteLine(sw.Elapsed); //10.10秒  9万条数据追加.
            */

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i <= 90000; i++)
            {
                sb.Append(i);
            }
            sw.Stop();

            Console.WriteLine(sw.Elapsed);  //0.013秒   9万条数据追加.

            Console.ReadKey();
        }
    }
}
