﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace StringBuilderTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            //1.创建StringBuilder 类型的变量.
            StringBuilder sb = new StringBuilder();

            //2.往sb 中追加数据.
            sb.Append("Monkey");
            sb.Append(123456);
            sb.Append(true);

            for (int i = 0; i <= 100; i++)
            {
                sb.Append(i);
            }
            Console.WriteLine(sb.ToString());
            sb.Clear(); //清空.
            Console.WriteLine(sb.ToString());
            sw.Stop();

            Console.WriteLine(sw.Elapsed);

            Console.ReadKey();
        }
    }
}
