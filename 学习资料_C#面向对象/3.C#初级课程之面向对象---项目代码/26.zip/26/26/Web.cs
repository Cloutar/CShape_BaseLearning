﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _26
{
    class Web
    {
        private string webName;
        private string webUrl;

        public Web(string name, string url)
        {
            this.webName = name;
            this.webUrl = url;
        }

        public void Show()
        {
            Console.WriteLine("名字:{0}地址:{1}", webName, webUrl);
        }
    }
}
