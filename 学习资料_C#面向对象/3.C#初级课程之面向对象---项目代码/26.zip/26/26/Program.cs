﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _26
{
    class Program
    {
        static void Main(string[] args)
        {
            Web w1 = new Web("百度", "www.baidu.com");
            Web w2 = new Web("腾讯", "www.qq.com");
            w1.Show();
            w2.Show();

            //Monkey m1 = new Monkey();

            Monkey m1 = Monkey.Instance();
            Monkey m2 = Monkey.Instance();

            Console.WriteLine(m1 == m2);
            Console.WriteLine(w1 == w2);


            Console.ReadKey();
        }
    }
}
