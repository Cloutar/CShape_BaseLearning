﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21
{
    class Program
    {
        static void Main(string[] args)
        {
            Zi z = new Zi();
            z.Hello();
            z.World();
            z.B1();

            Console.ReadKey();
        }
    }
}
