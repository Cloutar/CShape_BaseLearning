﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend
{
    class LuoFei:Hero
    {
        public void NengLiangJingLing()
        {
            Console.WriteLine("能量精灵");
        }

        public void AnYingChuanShong()
        {
            Console.WriteLine("暗影传送");
        }

        public void ShiKongBengLie()
        {
            Console.WriteLine("时空迸裂");
        }
    }
}
