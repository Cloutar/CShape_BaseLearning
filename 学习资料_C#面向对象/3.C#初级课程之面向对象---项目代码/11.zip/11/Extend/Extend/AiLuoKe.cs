﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend
{
    class AiLuoKe:Hero
    {
        public void ShuiShiDaJi()
        {
            Console.WriteLine("碎石打击");
        }

        public void LieYanMaoGou()
        {
            Console.WriteLine("烈焰锚钩");
        }

        public void ZhanHuoPaoXiao()
        {
            Console.WriteLine("战火咆哮");
        }
    }
}
