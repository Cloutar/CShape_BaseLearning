﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend
{
    class TaiLa:Hero
    {
        public void JuLangChongJi()
        {
            Console.WriteLine("巨浪冲击");
        }

        public void YuanShuTuJi()
        {
            Console.WriteLine("元素突击");
        }

        public void FuChouShaLu()
        {
            Console.WriteLine("复仇杀戮");
        }
    }
}
