﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend
{
    class LuKaShi:Hero
    {
        public void JianShuXianJing()
        {
            Console.WriteLine("减速陷阱");
        }

        public void NengLiangLangChao()
        {
            Console.Write("能量浪潮");
        }

        public void XuanFengJianWu()
        {
            Console.WriteLine("旋风剑舞");
        }
    }
}
