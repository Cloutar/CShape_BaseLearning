﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04
{
    /// <summary>
    /// C(Controller)控制器层---用户处理逻辑.
    /// </summary>
    class UserController
    {
        //实例化一个User集合.
        List<User> userList = new List<User>();


        //增加数据.


        //删除数据.


        //修改数据.


        //查询数据.


    }
}
