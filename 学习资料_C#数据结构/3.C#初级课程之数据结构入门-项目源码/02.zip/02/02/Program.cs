﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02
{
    class Program
    {
        static void Main(string[] args)
        {
            //实例化一个集合.
            List<int> num = new List<int>();

            //添加数据.
            num.Add(5);
            num.Add(15);
            num.Add(25);
            num.Add(35);

            //读取数据.
            //Console.WriteLine(num[2]);
            for (int i = 0; i < num.Count; i++)
            {
                Console.WriteLine(num[i]);
            }

            //删除数据.
            num.RemoveAt(2);
            Console.WriteLine("--------------------");
            for (int i = 0; i < num.Count; i++)
            {
                Console.WriteLine(num[i]);
            }

            //修改数据.
            num[2] = 100;
            Console.WriteLine("--------------------");
            for (int i = 0; i < num.Count; i++)
            {
                Console.WriteLine(num[i]);
            }

            Console.ReadKey();
        }
    }
}
