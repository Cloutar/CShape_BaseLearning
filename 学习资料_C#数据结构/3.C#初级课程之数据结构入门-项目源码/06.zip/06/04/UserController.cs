﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04
{
    /// <summary>
    /// C(Controller)控制器层---用于处理逻辑.
    /// </summary>
    class UserController
    {
        //实例化一个User集合.
        List<User> userList = new List<User>();


        /// <summary>
        /// 增加数据.
        /// </summary>
        public void AddItem(User user)
        {
            userList.Add(user);
        }

        /// <summary>
        /// 通过姓名删除数据.
        /// </summary>
        public void RemoveByName(string name)
        {
            for (int i = 0; i < userList.Count; i++)
            {
                if(userList[i].Name == name)
                {
                    userList.Remove(userList[i]);
                }
            }
        }

        /// <summary>
        /// 通过地址删除数据.
        /// </summary>
        public void RemoveByAddress(string address)
        {
            for (int i = 0; i < userList.Count; i++)
            {
                if(userList[i].Address == address)
                {
                    userList.Remove(userList[i]);
                }
            }
        }

        //修改数据.


        /// <summary>
        /// 查询数据.
        /// </summary>
        public void ShowAll()
        {
            if (userList.Count == 0)
            {
                Console.WriteLine("尚未添加数据");
            }
            else
            {
                for (int i = 0; i < userList.Count; i++)
                {
                    Console.WriteLine(userList[i]);
                }
            }
        }

    }
}
