﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08
{
    /// <summary>
    /// V.视图.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //实例化控制器对象.
            PhoneController pc = new PhoneController();

            //添加.
            pc.AddItem("lkk", "15166791296");
            pc.AddItem("mk", "1234567890");

            //查看.
            pc.ShowAll();

            //修改.
            Console.WriteLine("---------------------------");
            pc.UpdateItem("mk", "110");
            pc.ShowAll();

            //删除.
            Console.WriteLine("---------------------------");
            pc.DelItem("mk");
            pc.ShowAll();

            Console.ReadKey();
        }
    }
}
