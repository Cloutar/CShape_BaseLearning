﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09
{
    class Program
    {
        static void Main(string[] args)
        {
            //实例化控制器对象.
            WebInfoController wc = new WebInfoController();

            wc.AddItem("百度", new Web("百度", "www.baidu.com", "李彦宏"));
            wc.AddItem("淘宝", new Web("淘宝", "www.taobao.com", "马云"));
            wc.AddItem("擅码网", new Web("擅码网", "www.mkcode.net", "李开坤"));
            wc.AddItem("百度", new Web("百度", "baidu.com", "baidu"));

            wc.ShowAll();

            Console.WriteLine("--------------------");
            wc.DelItem("淘宝");
            wc.ShowAll();
            
            Console.WriteLine("--------------------");
            wc.UpdateItem("百度", new Web("百度", "www.baidu.com", "lkk"));
            wc.ShowAll();

            Console.ReadKey();
        }
    }
}
