﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01
{
    class Program
    {
        static void Main(string[] args)
        {
            //变量.单个数据.
            int numA = 10;
            float numB = 3.14f;
            bool isStart = false;

            Console.WriteLine("{0} - {1} - {2}", numA, numB, isStart);

            Console.WriteLine("---------int类型数组------------");
            //数组.int类型数组.
            int[] numC = new int[3];
            numC[0] = 10;
            numC[1] = 20;
            numC[2] = 30;
            for (int i = 0; i < numC.Length; i++)
            {
                Console.WriteLine(numC[i]);
            }

            Console.WriteLine("---------float类型数组------------");
            //数组.float类型数组.
            float[] numD = new float[] { 1.2f, 2.4f, 3.5f, 5.5f };
            for (int i = 0; i < numD.Length; i++)
            {
                Console.WriteLine(numD[i]);
            }

            Console.WriteLine("---------bool类型数组------------");
            //数组.bool类型数组.
            bool[] isStarts = new bool[3] { false, false, true };
            for (int i = 0; i < isStarts.Length; i++)
            {
                Console.WriteLine(isStarts[i]);
            }

            Console.ReadKey();
        }
    }
}
